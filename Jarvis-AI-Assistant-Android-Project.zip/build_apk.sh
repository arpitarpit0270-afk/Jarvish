#!/usr/bin/env bash
echo "========================================="
echo "  JARVIS AI - Termux Low-Memory APK Builder"
echo "========================================="

export GRADLE_OPTS="-Xmx512m -XX:MaxMetaspaceSize=256m"
export JAVA_OPTS="-Xmx512m"

if ! command -v gradle &> /dev/null
then
    echo "[!] Installing openjdk-17 and gradle..."
    pkg update && pkg install openjdk-17 gradle -y
fi

cd android || exit 1
echo "[*] Compiling APK using Gradle (Low RAM Mode)..."
gradle assembleDebug --no-daemon -Dorg.gradle.jvmargs="-Xmx512m -XX:MaxMetaspaceSize=256m"

if [ -f "app/build/outputs/apk/debug/app-debug.apk" ]; then
    echo "========================================="
    echo " [SUCCESS] APK built successfully!"
    echo " Location: ~/storage/downloads/jarvis_app/android/app/build/outputs/apk/debug/app-debug.apk"
    echo "========================================="
else
    echo "[X] Build finished. Check output above for details."
fi
