# JARVIS AI Assistant - Android Studio Quick Run Guide

## Error Fix: Android Studio Mein App Run Na Hone Par Kya Karein?

Agar aap Android Studio mein **Run (Shift+F10)** per click kar rahe hain aur error aa raha hai, to follow karein ye steps:

### 1. Common Error Solutions:
- **Error: Cleartext Traffic Not Permitted**
  -> Make sure `AndroidManifest.xml` mein `android:usesCleartextTraffic="true"` added hai.
- **Error: Internet / Connection Failed**
  -> Add `<uses-permission android:name="android.permission.INTERNET" />` in `AndroidManifest.xml`.
- **Error: Gradle Sync / JDK Mismatch**
  -> In Android Studio: Go to **File -> Settings -> Build, Execution, Deployment -> Build Tools -> Gradle** and set JDK to **JDK 17**.

---

## Complete Steps to Build APK in Android Studio:
1. Open Android Studio -> Select **New Project** -> Choose **Empty Activity** (Language: **Kotlin**).
2. Set Package Name: `com.jarvis.aiassistant`
3. Replace `app/src/main/AndroidManifest.xml` with the file inside `android/AndroidManifest.xml`.
4. Replace `app/src/main/java/com/jarvis/aiassistant/MainActivity.kt` with `android/MainActivity.kt`.
5. In `app/build.gradle.kts`, ensure `compileSdk = 34` and `minSdk = 24`.
6. Click **Sync Project with Gradle Files**.
7. Click **Build -> Build Bundle(s) / APK(s) -> Build APK(s)** to generate installable APK!
